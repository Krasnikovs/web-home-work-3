/*
 * Enter your name, surname and student id number here
 */

window.addEventListener('DOMContentLoaded', (event) => { // execute the code when the initial HTML document has been completely loaded
    
	let lookup = {};

    books.forEach(book => {
        if (book.genre && !(book.genre in lookup)) { // if the genre hasn't been previously processed
			lookup[book.genre] = 1; // add a new genre to the lookup
		}
    })

	// console.log(lookup); // uncomment this line if you want to see the result in the console

	// now let's sort genres for the first select element
	const genres = Object.keys(lookup).sort(); // get the list of keys in the lookup and sort it

	// console.log(genres); // uncomment this line if you want to see the result in the console

	// write your code to fill the select element

});

